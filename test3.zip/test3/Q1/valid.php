<?php
$errors = array();
if(!isset($_POST['name']) or empty($_POST['name'])){

    $errors['name'] = 'Name is required';

}

if(!isset($_POST['email']) or empty($_POST['email'])){

    $errors['email'] = 'Email is required';

}

if(isset($_FILES['image']) and !empty($_FILES['image']['name'])){

    $imgName = $_FILES['image']['name'];
    $imgTmpName = $_FILES['image']['tmp_name'];

    $ext = pathinfo($imgName)['extension'];

    $imgName = "images/".time().".".$ext;

    if(in_array($ext, array('png', 'jpg'))){
        
        move_uploaded_file($imgTmpName, $imgName);

    }else{

        $errors['img'] = 'Invalid';
        
    }

    
}
else{
    
    $errors['img'] = 'Invalid';
    
}

if(empty($errors)){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $img = $imgName;
    
    $file = fopen('info.txt', 'a');
    $newUser = "$name:$email:$img\n";

    fwrite($file, $newUser);

    fclose($file);

    header("Location:User.php");


}else{


    $formErrors = json_encode($errors);

    var_dump($formErrors);
    
    header("Location:adduser.php?errors=$formErrors");
    
}
?>