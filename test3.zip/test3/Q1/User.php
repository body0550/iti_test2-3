<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


</head>
<body>
    
</body>
</html>
<?php
 $data = file('info.txt');
 echo "
 
 <table class='table w-75'> 
 
 <tr class='bg-info'>
 <th  class='w-20'>Username </th>
 <th  class='w-20'>Email </th>
 <th  class='w-20'>Image </th>
 
 </tr>
 ";
 foreach ($data as $value) {
        
    $user = explode(':', $value);

    echo "<tr>";
    foreach ($user as $key => $value) {
        if($key<2){
            echo  "<td> $value </td>";
        }
    }
    echo "<td> <img src='$user[2]' width='50px' height='50px'> </td>";

    echo "<td> <a class='btn btn-warning'> Edit </a></td>";
    echo "<td> <a href='delete.php?username={$user[0]}' class='btn btn-danger'> Delete </a></td>";
    echo "</tr>";


}

echo "</table>"
?>