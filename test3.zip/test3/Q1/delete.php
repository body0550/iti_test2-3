<?php
$username=$_GET["username"];

$users=file('info.txt');
foreach($users as $key=>$value){
    $data=explode(":" ,$value);
    if($username==$data[0]){
        unset($users [$key]);
        break;
    }
}
$NEWfile=fopen('info.txt','w');
foreach($users as $value){
    fwrite($NEWfile,$value);
}
fclose($NEWfile);
header("Location:User.php");
?>