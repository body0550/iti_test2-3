<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $email = $_POST["email"];

    // validate the password
    if (!preg_match('/^[a-z0-9_]{0,8}$/', $password)) {
        header("Location: index.php?error=invalid_password");
        exit;
    }

    $data = $username . ":" . $password . ":" . $email . ":" . $image . "\n";
    file_put_contents("users.txt", $data, FILE_APPEND);

    header("Location: login.php");
    exit;
}
?>